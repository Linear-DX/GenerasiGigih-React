# Linear-Music

This website can create playlist in spotify.

# How to Run the App

Klik this Link : https://generasi-gigih-react-chrismario-linear.vercel.app/

# Github
Link : https://github.com/Linear-DX/GenerasiGigih-React
