const artistName = (props) => {
    return (
        <div>
            <p>{props.artis}</p>
        </div>
    );
};

export default artistName;