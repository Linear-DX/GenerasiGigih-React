const title = (props) => {
    return (
        <div>
            <h4>{props.judul}</h4>
        </div>
    );
};

export default title;